const juicialtile = extendContent(Floor, "juicial-tile", {
  draw(tile){
    Draw.shader(Shaders.water);
    Draw.rect(Core.atlas.find(name + "-shad" ),tile.drawx(), tile.drawy());
    Draw.shader();
  }
});